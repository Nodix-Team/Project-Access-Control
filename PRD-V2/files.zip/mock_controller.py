#!/usr/bin/env python3
"""
mock_controller.py — Simulator Controller ESP32 (kontrak MQTT v0.2)

Gunanya: mengetes Backend TANPA ESP32 sama sekali.
Jalankan 2 instance sekaligus untuk membuktikan bug P0-1 (door_id vs door_number)
tidak terjadi — bug itu TIDAK AKAN MUNCUL kalau Anda hanya menjalankan satu.

Pakai:
    pip install paho-mqtt
    python mock_controller.py --device-id ctrl-A --doors 4
    python mock_controller.py --device-id ctrl-B --doors 2 --drop-rate 0.2

Perintah interaktif (ketik di terminal):
    AABBCCDD 2      → simulasi tap kartu AABBCCDD di pintu 2
    LIST            → tampilkan daftar user yang tersimpan di "flash"
    OFFLINE         → putus paksa (uji deteksi offline via LWT)
"""
import argparse
import json
import os
import random
import sys
import threading
import time

import paho.mqtt.client as mqtt

PROTO = "v1"


class MockController:
    def __init__(self, device_id, broker, port, total_doors, heartbeat_s,
                 drop_rate=0.0, username=None, password=None):
        self.device_id = device_id
        self.total_doors = total_doors
        self.heartbeat_s = heartbeat_s
        self.drop_rate = drop_rate          # simulasi pesan hilang saat sync
        self.boot_ts = time.time()

        self.flash_path = f"flash_{device_id}.json"
        self.users = self._load_flash()     # {kartu_upper: [door_number, ...]}
        self.staging = None                 # daftar baru saat sync (BUKAN pengganti langsung)
        self.sync_id = None
        self.staged_count = 0

        self.base = f"access/{device_id}"
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                  client_id=device_id)
        if username:
            self.client.username_pw_set(username, password)

        # Last Will & Testament — broker yang publish 'offline' kalau kita mati mendadak
        self.client.will_set(f"{self.base}/status/lwt", "offline", qos=1, retain=True)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.connect(broker, port, 60)

    # ── "LittleFS" ────────────────────────────────────────────
    def _load_flash(self):
        if os.path.exists(self.flash_path):
            with open(self.flash_path) as f:
                return json.load(f)
        return {}

    def _save_flash(self):
        with open(self.flash_path, "w") as f:
            json.dump(self.users, f, indent=2)

    def _uptime_ms(self):
        return int((time.time() - self.boot_ts) * 1000)

    # ── MQTT ──────────────────────────────────────────────────
    def _on_connect(self, client, userdata, flags, rc, props=None):
        print(f"[{self.device_id}] terhubung ke broker (rc={rc})")
        client.subscribe(f"{self.base}/users/#", qos=1)
        client.subscribe(f"{self.base}/config/#", qos=1)
        client.publish(f"{self.base}/status/lwt", "online", qos=1, retain=True)
        self._publish_status()

    def _on_message(self, client, userdata, msg):
        topic = msg.topic[len(self.base) + 1:]
        payload = msg.payload.decode()
        print(f"[{self.device_id}] ← {topic}  {payload!r}")

        parts = payload.split(",")
        if not parts or parts[0] != PROTO:
            print(f"[{self.device_id}] !! versi payload tidak dikenal, DITOLAK")
            return
        body = parts[1:]

        if topic == "users/set":
            self._handle_set(body)
        elif topic == "users/delete":
            self._handle_delete(body)
        elif topic == "users/sync/start":
            self._handle_sync_start(body)
        elif topic == "users/sync/end":
            self._handle_sync_end(body)
        elif topic == "config/request":
            self._publish_config()
        elif topic == "config/set":
            self._handle_config_set(body)
        else:
            print(f"[{self.device_id}] !! topic tidak dikenal: {topic}")

    # ── Handler ───────────────────────────────────────────────
    def _parse_doors(self, s):
        """Filter ke rentang 1..total_doors — persis seperti firmware.
        Kalau Backend salah kirim door_id (mis. 6) ke controller 2-pintu,
        pintu itu akan DIBUANG DI SINI dalam diam. Itulah bug P0-1."""
        out, dropped = [], []
        for tok in s.split("|"):
            if not tok.strip():
                continue
            d = int(tok)
            if 1 <= d <= self.total_doors:
                out.append(d)
            else:
                dropped.append(d)
        if dropped:
            print(f"[{self.device_id}] ⚠️  DOOR DI LUAR RENTANG DIBUANG: {dropped} "
                  f"(total_doors={self.total_doors}) ← INDIKASI BUG P0-1 DI BACKEND")
        return out

    def _handle_set(self, body):
        kartu = body[0].upper()
        doors = self._parse_doors(body[1] if len(body) > 1 else "")

        if self.staging is not None:               # sedang sync
            if random.random() < self.drop_rate:   # simulasi pesan hilang
                print(f"[{self.device_id}] 💥 pesan sengaja DI-DROP (uji sync)")
                return
            self.staging[kartu] = doors
            return

        self.users[kartu] = doors                  # upsert biasa
        self._save_flash()
        print(f"[{self.device_id}] upsert {kartu} → {doors}")

    def _handle_delete(self, body):
        kartu = body[0].upper()
        self.users.pop(kartu, None)                # idempoten
        self._save_flash()
        print(f"[{self.device_id}] hapus {kartu}")

    def _handle_sync_start(self, body):
        self.sync_id = body[0]
        self.staging = {}                          # daftar LAMA tetap dipakai
        print(f"[{self.device_id}] sync {self.sync_id} MULAI (staging)")

    def _handle_sync_end(self, body):
        sync_id, expected = body[0], int(body[1])
        got = len(self.staging or {})
        if sync_id != self.sync_id:
            print(f"[{self.device_id}] sync_id tidak cocok, abaikan")
            return

        if got == expected:                        # commit atomik
            self.users = self.staging
            self._save_flash()
            result = f"{PROTO},{sync_id},OK,{got}"
            print(f"[{self.device_id}] ✅ sync OK — commit {got} user")
        else:                                      # buang staging, pertahankan lama
            result = f"{PROTO},{sync_id},MISMATCH,{got}"
            print(f"[{self.device_id}] ❌ sync MISMATCH (harap {expected}, dapat {got}) "
                  f"— daftar LAMA dipertahankan, pintu tetap bisa dibuka")

        self.staging, self.sync_id = None, None
        self.client.publish(f"{self.base}/sync/result", result, qos=1)

    def _handle_config_set(self, body):
        key, val = body[0], body[1]
        if key == "heartbeat_s":
            self.heartbeat_s = int(val)
        elif key == "total_doors":
            self.total_doors = int(val)
        print(f"[{self.device_id}] config {key} = {val}")
        self._publish_config()

    # ── Publish ───────────────────────────────────────────────
    def _publish_config(self):
        # CATATAN: wifi_pass TIDAK PERNAH dikirim balik.
        payload = f"{PROTO},{self.device_id},{self.total_doors},MOCK_SSID,mock-broker,1883,{self.heartbeat_s}"
        self.client.publish(f"{self.base}/config/response", payload, qos=1)

    def _publish_status(self):
        payload = f"{PROTO},{self.total_doors},-55,247000,{self._uptime_ms()}"
        self.client.publish(f"{self.base}/status", payload, qos=1)

    def tap(self, kartu, door):
        kartu = kartu.upper()
        if door < 1 or door > self.total_doors:
            result, reason = "DENIED", "INVALID_DOOR"
        elif kartu not in self.users:
            result, reason = "DENIED", "UNKNOWN_CARD"       # tetap di-log!
        elif door in self.users[kartu]:
            result, reason = "GRANTED", "OK"
        else:
            result, reason = "DENIED", "NO_ACCESS"

        payload = f"{PROTO},{kartu},{door},{result},{reason},{self._uptime_ms()}"
        self.client.publish(f"{self.base}/logs", payload, qos=1)
        print(f"[{self.device_id}] → TAP {kartu} pintu {door}: {result} ({reason})")

    def heartbeat_loop(self):
        while True:
            time.sleep(self.heartbeat_s)
            self._publish_status()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device-id", default="ctrl-A")
    p.add_argument("--broker", default="localhost")
    p.add_argument("--port", type=int, default=1883)
    p.add_argument("--doors", type=int, default=4)
    p.add_argument("--heartbeat", type=int, default=10)
    p.add_argument("--drop-rate", type=float, default=0.0,
                   help="0.2 = 20%% pesan users/set saat sync sengaja hilang")
    p.add_argument("--username")
    p.add_argument("--password")
    a = p.parse_args()

    ctrl = MockController(a.device_id, a.broker, a.port, a.doors,
                          a.heartbeat, a.drop_rate, a.username, a.password)

    threading.Thread(target=ctrl.client.loop_forever, daemon=True).start()
    threading.Thread(target=ctrl.heartbeat_loop, daemon=True).start()
    time.sleep(1)

    print(f"\n[{a.device_id}] siap. Ketik: '<KARTU> <PINTU>' | LIST | OFFLINE | CTRL-C keluar\n")
    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            up = line.upper()
            if up == "LIST":
                print(json.dumps(ctrl.users, indent=2))
            elif up == "OFFLINE":
                print("simulasi mati mendadak — broker harus publish LWT 'offline'")
                ctrl.client.disconnect()
                break
            else:
                try:
                    kartu, door = line.split()
                    ctrl.tap(kartu, int(door))
                except ValueError:
                    print("format: <KARTU> <NOMOR_PINTU>   contoh: AABBCCDD 2")
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
